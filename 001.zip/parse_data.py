"""
This module can read and parse the measured data of the vibrational
sensors of the metallic sealing test rig.
"""
from pathlib import Path
from re import search
from typing import Optional

from pandas import DataFrame, read_csv
from numpy import linspace, around


def get_file_index(file: Path) -> tuple[str, int]:
    """
    Read the name of the run and the index of the simulation from an exported
    experimental data file.
    
    Arguments:
    file: This is a single data file
    
    Returns:
    name of run; e.g. U_Vibration_1
    index of run; e.eg 0-99
    """
    with open(file, "r", encoding="utf-8") as read_file:
        for i, line in enumerate(read_file):
            if i == 2:  # 3th line
                match = search(r"/.+/(.+)/(\d+)", line)
                return match.group(1), int(match.group(2))
                
                
def assign_to_slice(result: DataFrame, input_: DataFrame, name: str, offset: int) -> None:
    """
    Assign the values of input_ to result[ofset::len(input_)].
    This function uses numpy arrays to bypass restrictions on pandas-dataframes.
    """
    input_array = input_["U"].to_numpy()
    result_array = result[name].to_numpy()
    n_oversample = len(result_array)//len(input_array)
    result_array[offset::n_oversample] = input_array
    result[name] = result_array
    
    
def make_length_uniform(data: dict[str, dict[int, DataFrame]]) -> None:
    """
    Reduce the lengths of every pandas DataFrame inside of this dictionary,
    so that they have exactly the same size.
    """
    # reduce the size of the input series to the size of the smallest input
    smallest_time: Optional[DataFrame] = None
    for sensor_type in data.values():
        for measurement in sensor_type.values():
            if smallest_time is None:
                smallest_time = measurement["t"].to_frame()
            else:
                smallest_time = smallest_time.merge(measurement["t"])
                
    for sensor_type_key in data:
        for measurement_key in data[sensor_type_key]:
            data[sensor_type_key][measurement_key]\
                = data[sensor_type_key][measurement_key].merge(
                smallest_time, on="t", how="inner")
           
            
def parse_data(data_folder: Path) -> DataFrame:
    """
    Combine all measurements inside a folder into a single
    pandas dataframe.
    
    Arguments:
    data_folder: This folder contains all measurements of both sensors.
    
    Returns:
    data: A dataframe which contains the ordered data of all runs.
    """
    # read data
    series: dict[str, dict[int, DataFrame]] = {}
    

    for file in data_folder.glob("*.dat"):
        name, index = get_file_index(file)
        if name not in series:
            series[name] = {}
        series[name][index] =\
            read_csv(file, delimiter="\t", header=4, names=["t", "U"])
        
        series[name][index]["t"] = around(series[name][index]["t"].to_numpy(), -2)
    
    make_length_uniform(series)
    # create empty dataframe
    first_measurement = next(iter(series.values()))
    n_oversampling = len(first_measurement)
    n_measurement = len(first_measurement[0]["U"])
    result = DataFrame(
        columns=(["t"] + list(series.keys())),
        index=range(n_oversampling*n_measurement))
    
    # fill in results in correct order
    result["t"] = linspace(
        first_measurement[0]["t"][0],
        first_measurement[0].iloc[-1]["t"]
        + (first_measurement[0]["t"][1] - first_measurement[0]["t"][0]),
        num=n_oversampling*n_measurement,
        endpoint=False)
    
    for i_oversampling in range(n_oversampling):
        for measurement_name, measurement in series.items():
            assign_to_slice(result, measurement[i_oversampling], measurement_name, i_oversampling)
            # result.loc[i_oversampling::n_oversampling, measurement_name] =\
            #     measurement[i_oversampling]["U"]
    return result
