# data preprocessing

import numpy as np
from scipy import signal
from scipy.signal import savgol_filter


def preprocessing(data,column):
    col = data.iloc[:,column]
    windows_name = "hamming"
    f,x_welch1 = signal.welch(col,fs=100000,window=windows_name,nperseg=15000,scaling='density',average='mean')
    x_filter1 = savgol_filter(np.abs(x_welch1),21,1)
    return 

folder = Path("05.09/dls-export-2022-09-05-15-29-42M5")
data = parse_data(folder)
M5 = preprocessing(data,1)
